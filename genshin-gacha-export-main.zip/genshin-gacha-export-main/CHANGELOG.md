### 下载
 - Coding 制品库(推荐)：https://sunfkny.coding.net/public-artifacts/genshin-gacha-export/releases/packages
 - Github releases：https://github.com/sunfkny/genshin-gacha-export/releases
 - Github 下载加速：https://ghproxy.com

### 更新内容
优化读取 data_2 缓存逻辑 （可能不在开头结尾，找最新链接）
新增读取云·原神日志方式
