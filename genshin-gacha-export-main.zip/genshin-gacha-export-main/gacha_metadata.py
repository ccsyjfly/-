gacha_query_type_ids = ["100", "200", "301", "302"]
gacha_query_type_names = ["新手祈愿", "常驻祈愿", "角色活动祈愿", "武器活动祈愿"]
gacha_query_type_dict = dict(zip(gacha_query_type_ids, gacha_query_type_names))
gacha_type_dict = {
    "100": "新手祈愿",
    "200": "常驻祈愿",
    "301": "角色活动祈愿",
    "302": "武器活动祈愿",
    "400": "角色活动祈愿-2",
}
